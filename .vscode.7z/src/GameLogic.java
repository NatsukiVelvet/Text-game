import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/*_____________________________________________________________________________
    Credits to Code Student on yt for his guide

    https://www.youtube.com/playlist?list=PLiuAYTl0L-gHgqyWtUKAAhtrTymOLHd28

    We used his guide for strictly some part of GameLogic
_____________________________________________________________________________*/

public class GameLogic {
    static Random ran = new Random();
    static boolean isRunning;
    public static String name;
    public static String cloneUser = null;
    static Scanner scanner = new Scanner(System.in);
    public static ArrayList<Player> playerList = Main.playerList;
    public static ArrayList<Player> enemyList = Main.enemyList;
    public static ArrayList<Player> onField = Main.onField;
    public static ArrayList<Item> availableItem = Main.availableItems;
    public static ArrayList<Player> toAddList = new ArrayList<>();

    /* Story instances for the story */

    static Story Thanks = new Story("src/Story_folder/Thanks.txt", null);
    static Story ActThree_2 = new Story("src/Story_folder/ActThree_2.txt", Thanks);
    static Story ActThree = new Story("src/Story_folder/ActThree.txt", ActThree_2);
    static Story ActTwo_final = new Story("src/Story_folder/ActTwo_final.txt", ActThree);
    static Story ActTwo_3 = new Story("src/Story_folder/ActTwo_3.txt", ActTwo_final);
    static Story ActTwo_2 = new Story("src/Story_folder/ActTwo_2.txt", ActTwo_3);
    static Story ActTwo = new Story("src/Story_folder/ActTwo.txt", ActTwo_2);
    static Story ActOne = new Story("src/Story_folder/ActOne.txt", ActTwo);
    static Story Intro = new Story("src/Story_folder/Intro.txt", ActOne);
    static Story currentStory = Intro;

    // method to take user input from console

    public static int ReadInt(String prompt, int userChoice) {
        int input;

        do {
            System.out.print(prompt);
            try {
                input = Integer.parseInt(scanner.next());
            } catch (Exception e) {
                input = -1;
                System.out.println("Please enter an Integer: ");
            }
        } while (input > userChoice || input < 0);

        return input;
    }

    // method to clear out console with a lot of new blank lines

    public static void clearConsole() {
        for (int i = 0; i < 2; i++) {
            System.out.println();
        }
    }

    // method to print separator with length n

    public static void separator(int n) {
        for (int i = 0; i < n; i++) {
            System.out.print('-');
        }
        System.out.println();
    }

    // print title

    public static void printTitle(String title) {
        separator(20);
        System.out.println(title);

    }

    // continue (Do have to input something or else press enter alone wont do
    // anything)

    public static void toContinue() {
        System.out.println("\nEnter anything to continue");
        scanner.next();
    }

    /* starts the game sequence, begins with collecting the player's name */
    public static void startGame() throws FileNotFoundException, IOException {
        boolean nameset = false;

        System.out.println("Welcome to the game");
        System.out.println("For the best experience, please turn on Chrono Trigger's OST Orchestral Arrangement to max volume.");
        System.out.println("I recommend ' Frog's theme ' during battle sequence");
        ;
        separator(10);
        do {

            System.out.println("What is your name? (will be used for recording game scores): ");
            name = scanner.next();
            separator(30);
            System.err.println("Is this name correct?");
            System.out.println("1 -> Aye");
            System.out.println("2 -> Nay");

            int input = ReadInt("-> ", 2);
            if (input == 1) {
                nameset = true;
            }
        } while (!nameset);

        System.out.println("From now on til forever more, thou shalt be called, Sir " + name);
        System.out
                .println("To interact with the Game, simply press the corresponding number when an input is required");
        System.out.println("For 'Enter anything to continue' simply type in anything and then enter to continue");
        toContinue();
        // Print story intro
        currentStory = Story.printStory(currentStory);

        // setting isRunning to true, so the gameloop can continue
        isRunning = true;

        gameLoop();

    }

    /*
     * prompts the Player to choose a target for their moves
     * works for our team and Enemy team
     */
    public static Player chooseTarget(Player user) {
        separator(20);
        Player chosenTarget = null;
        if (playerList.contains(user)) {
            for (int i = 0; i < enemyList.size(); i++) {
                if (enemyList.get(i).current_HP > 0) {
                    System.out.println(i + " -> " + enemyList.get(i).name);
                }

            }

            int chooseTarget = ReadInt("Choose a target: ", enemyList.size() - 1);
            chosenTarget = enemyList.get(chooseTarget);
        }

        else if (enemyList.contains(user)) {
            for (int i = 0; i < playerList.size(); i++) {
                if (playerList.get(i).current_HP > 0) {
                    System.out.println(i + " -> " + playerList.get(i).name);
                }
            }

            int chooseTarget = ReadInt("Choose a target: ", playerList.size() - 1);
            chosenTarget = playerList.get(chooseTarget);
        }

        return chosenTarget;
    }

    /*
     * prompts the player to choose a character to heal from their team
     */
    public static Player choose_to_heal(Player user) {
        separator(20);
        Player chosenTarget = null;
        if (playerList.contains(user)) {
            for (int i = 0; i < playerList.size(); i++) {
                if (playerList.get(i).current_HP > 0) {
                    System.out.println(i + " -> " + playerList.get(i).name);
                }

            }

            int chooseTarget = ReadInt("Choose a target: ", playerList.size() - 1);
            chosenTarget = playerList.get(chooseTarget);
        }

        else if (enemyList.contains(user)) {
            for (int i = 0; i < enemyList.size(); i++) {
                if (enemyList.get(i).current_HP > 0) {
                    System.out.println(i + " -> " + enemyList.get(i).name);
                }
            }

            double randomPlayer = 0 + ((Main.enemyList.size() - 1) - 0) * ran.nextDouble();

            chosenTarget = enemyList.get((int) randomPlayer);
        }

        return chosenTarget;
    }

    /*
     * BATTLE!!!
     * BATTLE LOOP BY FILLING ACTION GAUGE AND RESET IT
     * ENDS ONCE ALL ENEMIES ARE KILLED
     * OR ALL PLAYERS HAVE DIED
     */

    public static void battle() throws IOException {
        boolean isBattling = true;

        while (isBattling) {

            /*
             * since Java doesn't allow removing mid-iteration,
             * then we make a temp list to remove at the end of the iteration
             */

            ArrayList<Player> toRemove = new ArrayList<>();

            for (Player play : onField) {

                // check if the character on the field is ready to take action
                if (!play.isReady) {
                    play.fillGauge();
                }

                else if (play.current_HP > 0 && play.isReady) {
                    clearConsole();
                    printTitle(play.name + "'s turn to take action");
                    play.resetGauge();

                    if (enemyList.contains(play)) {
                        play.enemy_useMove();
                    } else {
                        play.useMove();
                    }

                }

                else if (play.current_HP <= 0) {
                    toRemove.add(play);
                }

            }
            /*
             * register death by looping through Player instances in the toRemove list
             * remove those player from the onField and playerList/enemyList
             */
            for (Player deadman : toRemove) {
                playerDied(deadman);
                
            }
   
            // for the cloning technique
            if (cloneUser == "Hero") {
                playerList.addAll(toAddList);
                onField.addAll(toAddList);
                cloneUser  = null;
   

            } else if (cloneUser == "Villain") {
                enemyList.addAll(toAddList);
                onField.addAll(toAddList);
                cloneUser = null;
         
            }
            /*
             * Ends game if both main character have died
             * Lil Black Mage Vivi can't possibly know how to save the world alone, can he?
             */
            if (!playerList.contains(Main.Nikolas) && !playerList.contains(Main.Eli)) {
                System.out.println("But... The future refused to change");
                System.out.println("Game over");
                System.out.println("See your results in result.csv");
                saveGame.gameResult("Result.csv");
                isRunning = false;
                isBattling = false;
                ;
            }

            else if (enemyList.isEmpty()) {
                System.out.println("All enemies vanquished!!!");
                System.out.println("");
                isBattling = false;
            }

            // remove clones from the toAddList
            toAddList.clear();
;



        }

    }

    /*
     * Register Player Instance death by removing them from both onField and their respective player/enemy List
     * Death is permanent, until the start of the next game
     */
    public static void playerDied(Player deadMan) {

        if (playerList.contains(deadMan)) {
            playerList.remove(deadMan);
            onField.remove(deadMan);
        }

        else if (enemyList.contains(deadMan)) {
            enemyList.remove(deadMan);
            onField.remove(deadMan);
        }

    }

    /*
     * Prints the Menu after each battle or act
     */
    public static void printMenu() {
        printTitle("MENU");
        System.out.println("Choose an option: ");
        System.out.println("1 -> continue with the journey");
        System.out.println("2 -> Go to character setup");
        System.out.println("3 -> Exit game");
    }

    /*
     * In case the player wants to end game, prints credit
     * and produce the result csv
     */
    public static void Credits() throws FileNotFoundException, IOException {
        currentStory = Thanks;
        Story.printStory(currentStory);
        saveGame.gameResult("Result.csv");
        isRunning = false;

    }

    /*
     * Checks story and load character in correspondingly
     */
    public static void continueJourney() throws FileNotFoundException, IOException {

        // check if act should be progress

        if (currentStory.equals(ActOne)) {
            load_Enemy(Main.wild_goons_1);
            load_Enemy(Main.wild_goons_2);
            currentStory = Story.printStory(currentStory);//ActOne then returns ActTwo
            battle();

            return;

        }

        if (currentStory.equals(ActTwo)) {
            currentStory = Story.printStory(currentStory);
            currentStory = Story.printStory(currentStory);// ActTwo_2 returns to ActTwo_3
            load_Player(Main.Eli);
            return;
        }
        if (currentStory.equals(ActTwo_3)) {

            currentStory = Story.printStory(currentStory);// ActTwo_3 returns to ActTwo_final
            load_Enemy(Main.Kirill);
            load_Enemy(Main.wild_goons_1);
            load_Enemy(Main.wild_goons_2);
            load_Enemy(Main.Lila);

            battle();
            onField.remove(Move.clone);
            playerList.remove(Move.clone);

            currentStory = Story.printStory(currentStory);// ActTwo_final returns to ActThree
            return;
        }
        if (currentStory.equals(ActThree)) {
            currentStory = Story.printStory(currentStory);// actThree returns to ActThree_2
            load_Enemy(Main.Demon);
            battle();
            currentStory = Story.printStory(currentStory);// ActThree_2 returns to Thanks
            return;
        }

        if (currentStory.equals(Thanks)) {
            currentStory = Story.printStory(currentStory);
            saveGame.gameResult("Result.csv");
            isRunning = false;
            return;

        }

    }

    public static void characterSetUp() {
        // choose a character in team and print their info along with options to equip
        // and unequip gear
        //
        separator(20);
        System.out.println("Choose a character you want to inspect ");
        for (int i = 0; i < playerList.size(); i++) {
            System.out.println(i + " -> " + playerList.get(i).name);
        }
        separator(20);

        int chooseCharacter = ReadInt("-> ", playerList.size() - 1);
        Player chosen = playerList.get(chooseCharacter);
        separator(10);
        chosen.displayStats();
        separator(10);
        chosen.displayMoveset();
        separator(10);
        chosen.displayItem();

        itemSetUp(chosen);
    }

    
    /*
     * The main game loop, using the printMenu() method and user's input to determine the next course of action
     */
    public static void gameLoop() throws FileNotFoundException, IOException {
        while (isRunning) {
            printMenu();
            int input = ReadInt("-> ", 3);
            if (input == 1) {
                continueJourney();
            }
            if (input == 2) {
                characterSetUp();
            }
            if (input == 3) {
                Credits();
                break;

            }

        }
    }
    /*
     * self explanatory
     * Based on user's input, allow them to choose Item for certain characters
     */
    public static void itemSetUp(Player user) {
        printTitle("Equip/Unequip some items?");
        System.out.println("1 -> Equip");
        System.out.println("2 -> Unequip");
        System.out.println("3 -> Return to menu");

        int chosen_option = ReadInt("-> ", 3);

        // should this be a separate method???
        switch (chosen_option) {

            case 1:

                while (true) {

                    printTitle("What would you like to equip? (press 0 to return to menu)");

                    for (int i = 1; i <= availableItem.size(); i++) {
                        System.out.println(i + "-> " + availableItem.get(i - 1).name);
                    }

                    int input_chosen_item = ReadInt("-> ", availableItem.size());

                    // stop the selection
                    if (input_chosen_item == 0) {
                        break;
                    }

                    Item chosen_Item = availableItem.get(input_chosen_item - 1);

                    separator(10);
                    chosen_Item.displayStatBoost();

                    boolean equip_choice = equip_confirmation();
                    if (equip_choice) {
                        user.equip(chosen_Item);
                        remove_Item_from_list(chosen_Item);
                    } else {

                    }
                }

                break;

            case 2:

                while (true) {

                    printTitle("What item would you like to unequip? (press 0 to return to menu)");

                    for (int i = 1; i <= user.equippedItem.size(); i++) {
                        System.out.println(i + "-> " + user.equippedItem.get(i - 1).name);
                    }

                    int input_chosen_item = ReadInt("-> ", user.equippedItem.size());

                    // stop the selection
                    if (input_chosen_item == 0) {
                        break;
                    }

                    Item chosen_Item = user.equippedItem.get(input_chosen_item - 1);

                    separator(10);
                    chosen_Item.displayStatBoost();
                    boolean unequip_choice = equip_confirmation();

                    if (unequip_choice) {
                        user.unequip(chosen_Item);
                        add_Item_to_list(chosen_Item);
                    } else {

                    }
                }
                break;

            default:
                break;
        }
    }


    /*
     * If item was equipped, removed it from the list of available Items
     */
    public static void remove_Item_from_list(Item selected) {
        availableItem.remove(selected);
    }

    /*
     * if item was unequipped, add to the availableItem list
     */
    public static void add_Item_to_list(Item selected) {
        availableItem.add(selected);
    }

    /*
     * Checks user input for equip/unequip an item
     */

    public static boolean equip_confirmation() {
        printTitle("Equip / Unequip this?");
        System.out.println("1 -> Yes");
        System.out.println("2 -> No");
        int choice = ReadInt("-> ", 2);
        switch (choice) {
            case 1:
                return true;
            default:
                return false;

        }
    }

    //Loads the Player instance into their corresponsing list along with onField list  

    public static void load_Enemy(Player enemy) {
        enemyList.add(enemy);
        onField.add(enemy);
    }

    public static void load_Player(Player player) {
        playerList.add(player);
        onField.add(player);
    }

}
