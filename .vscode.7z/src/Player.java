import java.lang.Math;
import java.util.Random;

public class Player extends Character {

    Random randomModifier = new Random();
    Random ran = new Random();

    public Player(String name, int speed, double ATK, double Magic, double HP, double DEF, double Mag_DEF) {
        super(name, speed, ATK, Magic, HP, DEF, Mag_DEF);

        // TODO Auto-generated constructor stub
    }

    public void addMove(Move move) {
        this.moveset.add(move);
    }

    // use a move
    public void useMove() {
        Move moveChosen;
        Player target = null;
        displayMoveset();
        int moveInput = GameLogic.ReadInt("Choose a move: ", this.moveset.size()-1);
        moveChosen = this.moveset.get(moveInput);

        if (moveChosen.type == "Heal") {
            target = GameLogic.choose_to_heal(this);
        } else {
            target = GameLogic.chooseTarget(this);
            GameLogic.separator(15);
        }

    

        if (moveChosen.type == "Clone") {
            moveChosen.useMove_clone(this);
        } else if (moveChosen.type == "Heal") {
            moveChosen.heal(this, target);
        } else {
            moveChosen.useMove(this, target);
        }

        // TODO: implement a method called chooseTarget (will be from characters that
        // are on field)

    }

    public void enemy_useMove() {
        Player target = null;
        GameLogic.separator(15);
        double randomMove = 0 + ((this.moveset.size() - 1) - 0) * ran.nextDouble();
        double randomPlayer = 0 + ((Main.playerList.size() - 1) - 0) * ran.nextDouble();

        Move moveChosen = this.moveset.get((int) randomMove);

        if (moveChosen.type == "Heal") {
            target = GameLogic.choose_to_heal(this);
            moveChosen.heal(this, target);
        }

        target = Main.playerList.get((int) randomPlayer);
        moveChosen.useMove(this, target);

    }

    // damage calculation (More variable shall be added to make a difference between
    // physical, magical and support abilities)

    public double takeDamage(Player user, int damage, String type) {
        double DmgTaken = 0;
        double rounded = 0;
        double DmgRandom = 0;
        double DmgFinal = 0;

        // Physical formula
        if (type.equals("Physical")) {
            if (isCritical(user.current_crit)) {
                System.out.println("Critical Attack");
                DmgTaken = (((user.current_ATK * 4 / 3) + (damage * 5 / 9)) * 2) * ((256 - this.current_DEF) / 256);
                DmgRandom = (-DmgTaken * 15 / 100)
                        + (DmgTaken * 15 / 100 - (-DmgTaken * 15 / 100)) * randomModifier.nextDouble();
                DmgFinal = DmgTaken + DmgRandom;
                rounded = Math.round(DmgFinal);
                this.current_HP -= rounded;

            } else {

                DmgTaken = ((user.current_ATK * 4 / 3) + (damage * 5 / 9)) * ((256 - this.current_DEF) / 256);
                DmgRandom = (-DmgTaken * 15 / 100)
                        + (DmgTaken * 15 / 100 - (-DmgTaken * 15 / 100)) * randomModifier.nextDouble();
                DmgFinal = DmgTaken + DmgRandom;
                rounded = Math.round(DmgFinal);
                this.current_HP -= rounded;

            }
        }

        // Magical formula
        if (type.equals("Magical")) {
            if (isCritical(user.current_crit)) {
                System.out.println("Critical Attack");
                DmgTaken = (((damage * 1.75) + (user.current_Magic * 3 / 4.55)) * 2) * (102.4 - this.current_Mag_DEF)
                        / 128;
                DmgRandom = (-DmgTaken * 15 / 100)
                        + (DmgTaken * 15 / 100 - (-DmgTaken * 15 / 100)) * randomModifier.nextDouble();
                DmgFinal = DmgTaken + DmgRandom;
                rounded = Math.round(DmgFinal);
                this.current_HP -= rounded;

            } else {

                DmgTaken = (damage * 1.75) + (user.current_Magic * 3 / 4.55) * (102.4 - this.current_Mag_DEF) / 128;
                DmgRandom = (-DmgTaken * 15 / 100)
                        + (DmgTaken * 15 / 100 - (-DmgTaken * 15 / 100)) * randomModifier.nextDouble();
                DmgFinal = DmgTaken + DmgRandom;
                rounded = Math.round(DmgFinal);
                this.current_HP -= rounded;

            }
        }

        if (type.equals("Heal")) {

            DmgTaken = damage / 16 * ((user.current_Magic/4 + user.current_HP / 150) * 2);
            rounded = Math.round(DmgTaken);
            this.current_HP += rounded;
            if (this.current_HP >= this.HP) {
                this.current_HP = this.HP;
            }
        }

        // responds if target is dead, if not, continues battle

        if (this.current_HP <= 0) {
            this.current_HP = 0;
            System.out.println(this.name + " has perished, another one bites the dust!");
            // GameLogic.playerDied(this);
        } else {
            System.out.println(this.name + "'s remaining HP: " + this.current_HP + "/" + this.HP);
            // GameLogic.battle();
        }
        return rounded;

    }

    // display stats
    public void displayStats() {

        // crit is a double sooo....can't go into a int array

        double[] statList = { this.current_ATK, this.current_Magic, this.current_DEF, this.current_Mag_DEF,
                this.current_crit };

        String[] statName = { "ATK: ", "Magic: ", "DEF: ", "Magic Defense: ", "Critical chance: " };
        System.out.println(this.name + "'s " + "stats:");
        System.out.println("Current Health: " + this.current_HP + "/" + this.HP);
        for (int i = 0; i < statList.length; i++) {
            System.out.println(statName[i] + statList[i]);
        }
        System.out.println("Speed: " + this.current_speed);

    }

    // name is pretty self explanatory, display move set of a character
    public void displayMoveset() {
        System.out.println(this.name + "'s Moves:");
        for (int i = 0; i < this.moveset.size(); i++) {
            Move move = this.moveset.get(i);
            System.out.println(i + ": " + move.name + " (" + move.type + ", Power: " + move.power + ")");
        }
    }

    //again, self explanatory, display Item in a character's inventory

    public void displayItem() {
        System.out.println(this.name + "'s Items: ");
        for (int i = 0; i < this.equippedItem.size(); i++) {
            Item item = this.equippedItem.get(i);
            item.displayStatBoost();
        }
    }

    /* Helps player equip item by adding to their item arrayList */
    public void equip(Item item_equip) {

        this.equippedItem.add(item_equip);
        this.resetStat();
        for (Item item : equippedItem) {
            this.applyItemBuff(item);
        }

    }
    /* Helps player unequip item by removing from their item arrayList*/
    public void unequip(Item item_unequip) {
        this.equippedItem.remove(item_unequip);
        this.removeItemBuff(item_unequip);

    }

    // apply item's buff to the Player
    public void applyItemBuff(Item item) {
        this.current_HP += item.getStatBoost("Health");
        this.HP += item.getStatBoost("Health");
        this.current_ATK += item.getStatBoost("Attack");
        this.current_DEF += item.getStatBoost("Defense");
        this.current_Mag_DEF += item.getStatBoost("Magic Defense");
        this.current_Magic += item.getStatBoost("Magic");
        this.current_crit += item.getStatBoost("Critical Rate");
        this.current_speed += item.getStatBoost("Speed");
    }

    //remove buff from player
    public void removeItemBuff(Item item) {
        this.current_HP -= item.getStatBoost("Health");
        this.HP -= item.getStatBoost("Health");
        this.current_ATK -= item.getStatBoost("Attack");
        this.current_DEF -= item.getStatBoost("Defense");
        this.current_Mag_DEF -= item.getStatBoost("Magic Defense");
        this.current_Magic -= item.getStatBoost("Magic");
        this.current_crit -= item.getStatBoost("Critical Rate");
        this.current_speed -= item.getStatBoost("Speed");
    }

    //reset the player's stat to base value
    public void resetStat() {
        this.HP = this.base_HP;
        this.current_HP = this.base_HP;
        this.current_ATK = this.ATK;
        this.current_DEF = this.DEF;
        this.current_Mag_DEF = this.Mag_DEF;
        this.current_Magic = this.Magic;
        this.current_crit = this.crit;
        this.current_speed = this.speed;
    }

}
