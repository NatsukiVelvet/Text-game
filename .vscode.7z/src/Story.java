import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;

//Please download apache commons IO library 
public class Story {
    String actFile;
    Story nextAct;

    public Story(String actFile, Story nextAct) {
        this.actFile = actFile;
        this.nextAct = nextAct;
    }

    // found a way to read the text file, yay

    public static Story printStory(Story story) throws FileNotFoundException, IOException {
        GameLogic.clearConsole();
        GameLogic.separator(30);

        //if you want to use the apache commons IO ways, be my guest

        // try (FileInputStream inputStream = new FileInputStream(story.actFile)) {
        // String everything = IOUtils.toString(inputStream, "UTF-8");
        // everything.trim();
        // System.out.println(everything);

        // }

        Scanner reader = new Scanner(new FileReader(story.actFile));
        while (reader.hasNextLine()) {
            String line = reader.nextLine();
            String trimmed_line = line.trim();
            System.out.println(trimmed_line);
        }

        reader.close();

        GameLogic.toContinue();

        return story.nextAct;

    }

}
