import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;

public class saveGame {

    public static ArrayList<Item> availableItem = Main.availableItems;
    public static Random ran = new Random();

    public static String toCSV_String() {
        return GameLogic.name + "," + Move.global_DMG + "," + availableItem.size() + "," + scoreCalculate();

    }

    public static int weaponPawn(int size) {
        int total = 0;
        for (Item item : availableItem) {
            total += ran.nextInt(2000);
        }
        return total;
    }

    public static int scoreCalculate() {
        return (Move.global_DMG * (int) (150 + (300 - 150) * ran.nextDouble())) + weaponPawn(availableItem.size());
    }

    // method to save Character into cvs
    public static void gameResult(String filepath) throws IOException {
        FileOutputStream fileOutputStream = null;
        StringBuilder csvData = new StringBuilder();

        BufferedWriter writer = null;

        csvData.append("Name,Blood_Donated(Liter),Spare_Item,Total_Score\n");

        csvData.append(toCSV_String()).append('\n');

        /* IOUtils require downloading Apache commons IO library */

        // try {
        // fileOutputStream = new FileOutputStream(filepath);
        // IOUtils.write(csvData.toString(), fileOutputStream, "UTF_8");
        // System.out.println("See your results in " + filepath);
        // } catch (IOException e) {
        // e.printStackTrace();
        // } finally {
        // IOUtils.closeQuietly(fileOutputStream);
        // }
        // Use IOUtils to read the CSV data from the file

        try {
            writer = new BufferedWriter(new FileWriter("save.csv", true));
            writer.write(csvData.toString());

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            writer.close();
        }

    }

 
}