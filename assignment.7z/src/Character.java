import java.util.ArrayList;
import java.util.Random;


public class Character {
    String name;
    double ATK;
    double Magic;
    double HP;
    double DEF;
    double MP;
    double Mag_DEF;
    int speed; // Determines how fast the action gauge fills
    int gauge; // Current value of the action gauge (0 to 100)
    boolean isReady; // True if gauge reaches 100 and character is ready to act
    double crit;
    double base_HP;
    ArrayList<Move> moveset;


    double current_ATK;
    double current_Magic;
    double current_HP;

    double current_DEF;
    double current_Mag_DEF;
    int current_speed;
    double current_crit;
    ArrayList<Item> equippedItem;


    public Character(String name, int speed, double ATK, double Magic, double HP, double DEF, double Mag_DEF) {
        this.name = name;
        this.ATK = ATK;
        this.Magic = Magic;
        this.HP = HP;
        this.base_HP = HP;
        this.MP = MP;
        this.DEF = DEF;
        this.Mag_DEF = Mag_DEF;
        this.speed = speed;
        this.crit  =0.2;
        this.gauge = 0;
        
        this.current_ATK = ATK;
        this.current_Magic = Magic;
        this.current_HP = HP;

        this.current_DEF = DEF;
        this.current_Mag_DEF = Mag_DEF;
        this.current_speed = speed;
        this.current_crit = 0.2;

        this.isReady = false;
        this.moveset = new ArrayList<>();
        this.equippedItem = new ArrayList<>();

    }

//-----------------------------------------------------------------------------------------------

    // Critical Hit
    public static boolean isCritical(double chance){

        Random rand = new Random();

        double value = rand.nextDouble();

        return value <= chance;
    }

//----------------------------------------------------------------------------------------------------- 




//---------------------------------------------------------------------------------------------------------------------------
    public void fillGauge() {
        if (!isReady) {
            this.gauge += this.current_speed;
            if (this.gauge >= 100) {
                this.gauge = 100;
                this.isReady = true;
   
            }
        }
    }

    public void resetGauge() {
        this.gauge = 0;
        this.isReady = false;
    }








}



