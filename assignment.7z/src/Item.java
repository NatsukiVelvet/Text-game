import java.util.HashMap;

public class Item {
    
    String name;
    HashMap<String, Double> statBoost; //a dictionary of stat types and its buff (or debuff)

    public Item(String name){
        this.name = name;
        this.statBoost = new HashMap<>();
    }

    //add the stat name that item will buff (or debuff) along with its value in the hashmap
    public void addStatBoost(String stat, double boost){
        this.statBoost.put(stat, boost);
    }
    // return the value of the buff according to the key (ATK, HP, DEF.....)
    public Double getStatBoost(String stat){
        return this.statBoost.getOrDefault(stat,(double) 0);
        
    }
    //self-explanatory
    public void displayStatBoost(){
        System.out.println(this.name + ":");
        for (String i: this.statBoost.keySet()){
            System.out.println("   -   "  + i + ": " + this.statBoost.get(i));
        }

    }


}
