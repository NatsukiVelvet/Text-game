
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class Main {
    public static ArrayList<Player> playerList = new ArrayList<>();
    public static ArrayList<Player> enemyList = new ArrayList<>();
    public static ArrayList<Player> onField = new ArrayList<>();
    public static ArrayList<Item> availableItems = new ArrayList<>();
    

    public static Player Nikolas  =  new Player("Nikolas", 14,200,50,2000,100,25);
    public static Player Eli = new Player("Eli", 16,100,175,1560,100,100);
    public static Player Kirill = new Player("Kirill" , 13,50,200,2500,90,10);
    public static Player Lila = new Player("Lila", 15,150,60,2500,30,90);
    public static Player wild_goons_1 = new Player("Assassin of the Midnight Sun #1", 13,90,69,1200,50,50);
    public static Player wild_goons_2 = new Player("Assassin of the Midnight Sun #2", 13,86,69,1100,50,50);
    public static Player Demon = new Player("Demon", 18,250,200,3000,100,100);
    public static Move stab  = new Move("Stab" , "Physical", 35);
    public static Move Thundara = new Move("Thundara","Magical", 69);
    public static void main(String[] args) throws FileNotFoundException, IOException {

        Move healing_whisper = new Move("Healing Whispers", "Heal", 60);
        Move downward_slash = new Move("Upward Slash", "Physical" , 100);
        Move Hydro_Blast = new Move("Hydro Blast" , "Magical", 60);
        Move Ember = new Move ("Ember" , "Magical", 40);
        Move Mordhau = new Move("Mordhau", "Physical", 8000);
        Move summon_puppets = new Move("Summon Black Mage", "Clone" , 0);
        Move piercing_shot = new Move("Piercing Shot", "Physical", 55);
        Move Bandage = new Move("Poultice Bandage","Heal", 40);
        Move iron_wave = new Move ("Iron Wave ", "Physical", 80);
        Move Firaga = new Move("Firaga", "Magical",72);
        Move Blizzara = new Move("Blizzara", "Magical", 40);


        Item Buster = new Item("Buster Sword");
        Buster.addStatBoost("Attack", 35);
        Buster.addStatBoost("Speed", -3);

        Item Long = new Item("Long Sword");
        Long.addStatBoost("Attack", 15);
        Long.addStatBoost("Critical Rate", 0.3);

        Item talisman  = new Item("Everwatching talisman");
        talisman.addStatBoost("Magical Defense", 30);

        Item platemail = new Item("Platemail");
        platemail.addStatBoost("Defense", 35);
        platemail.addStatBoost("Magic", -30);

        Item witch_hat = new Item("'Witch hat Atelier', Signed copy");
        witch_hat.addStatBoost("Magic", 45);
        witch_hat.addStatBoost("Magical Defense", 15);
        witch_hat.addStatBoost("Attack", -55);

        availableItems.add(Buster);
        availableItems.add(Long);
        availableItems.add(talisman);
        availableItems.add(platemail);
        availableItems.add(witch_hat);
        
        Nikolas.addMove(downward_slash);
        Nikolas.addMove(Ember);
        Nikolas.addMove(Bandage);
        Nikolas.current_crit = 0.2;

        Eli.addMove(Hydro_Blast);
        Eli.addMove(stab);
        Eli.addMove(healing_whisper);
        Eli.addMove(summon_puppets);

        wild_goons_1.addMove(Mordhau);
        wild_goons_2.addMove(Mordhau);


        Kirill.addMove(healing_whisper);
        Kirill.addMove(summon_puppets);
        Kirill.addMove(stab);
        Kirill.addMove(Bandage);


        Lila.addMove(iron_wave);
        Lila.addMove(piercing_shot);
        Lila.addMove(healing_whisper);
        Lila.addMove(Mordhau);

        Demon.addMove(Blizzara);
        Demon.addMove(Thundara);
        Demon.addMove(Firaga);

        playerList.add(Nikolas);
        onField.add(Nikolas);

        GameLogic.startGame();

    }
}
