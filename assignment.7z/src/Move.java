import java.util.ArrayList;
import java.util.Arrays;

class Move {
    String name;
    String type; // "Physical" or "Magical"
    int power;
    public static int global_DMG; // Damage or healing value
    public static Player clone;

    public Move(String name, String type, int power) {
        this.name = name;
        this.type = type;
        this.power = power;
    }

    // Execute the move on a target character
    public void useMove(Player user, Player target) {
        double dmgTaken = target.takeDamage(user, power, type);

        // Only display damage message if the move is not a heal
        if (!type.equals("Heal") || !type.equals("Clone")) {
            global_DMG += dmgTaken/100;
            System.out.println(name + " (" + type + " attack) deals " + dmgTaken + " damage to " + target.name);

        }
    }
    //specific "Clone" Abilities logic
    public String useMove_clone(Player user) {
        
        if (Main.enemyList.contains(user) && Main.enemyList.size() == 5) {
            System.out.println("Group is too full, 5 villains in a team only");
        } else if (Main.playerList.contains(user) && Main.playerList.size() == 4) {
            System.out.println("Group is too full, 4 team members only");
        } else {
            if (Main.enemyList.contains(user)) {
                Player clone = new Player(user.name + "'s Clone", user.speed, user.ATK, user.Magic, user.HP,user.DEF, user.Mag_DEF);
                clone.moveset.add(Main.stab);
                GameLogic.toAddList.add(clone);
                System.out.println("From the shadows emerged a figure looks like "+user.name);
                return GameLogic.cloneUser = "Villain";
                
            } 

            clone = new Player(user.name + "'s Black Mage", (int)(user.speed/1.5), user.ATK/2, user.Magic/2, user.HP/2,user.DEF/1.2, user.Mag_DEF/1.2);
            clone.moveset.add(Main.Thundara);
            GameLogic.toAddList.add(clone);
            System.out.println("From the shadows emerged a lil guy");
            return GameLogic.cloneUser = "Hero";


        }
        return null;

    }
//specific "Heal" abilities logic
    public void heal(Player user, Player target) {
        double dmgTaken = target.takeDamage(user, power, type);
        System.out.println(name + " healed " + target.name + " for " + dmgTaken);
    }
}