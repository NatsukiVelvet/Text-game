import static org.junit.Assert.*;

import org.junit.Test;

public class testingJUnit {
    @Test
    public void testItem(){
        Item Masamune = new Item("Masamune");
        Masamune.addStatBoost("Attack", 100);
        Masamune.addStatBoost("Magic", 100);

        double attackBoost = Masamune.getStatBoost("Attack");
        assertEquals("Masamune",Masamune.name);
        assertEquals(100, attackBoost,0.1);

    }


    @Test
    public void testMove(){
        Move kick = new Move("Kick","Physical",50);
        assertEquals("Kick",kick.name);
        assertEquals("Physical",kick.type);
        assertEquals(50,kick.power);
    }

    @Test
    public void testStory(){
        Story copy_of_ActOne = new Story(GameLogic.ActOne.actFile,null);
        Story copy_of_Intro  = new Story(GameLogic.Intro.actFile, copy_of_ActOne);

        assertEquals("src/Story_folder/Intro.txt", copy_of_Intro.actFile);
        assertEquals(copy_of_ActOne,copy_of_Intro.nextAct);
    }

    @Test
    public void testPlayer(){
        Player NPC = new Player("NPC",1,1,1,1,1,1);

        Move kick = new Move("Kick","Physical",50);
        Item Masamune = new Item("Masamune");
        Masamune.addStatBoost("Attack", 100);
        Masamune.addStatBoost("Magic", 100);
        NPC.addMove(kick);
        NPC.equippedItem.add(Masamune);

        assertEquals(kick,NPC.moveset.get(0));
        assertEquals(Masamune, NPC.equippedItem.get(0));

    }
}
